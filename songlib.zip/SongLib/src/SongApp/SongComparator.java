
/* By Vishal Patel and Eshan Wadhwa */

package SongApp;

import java.util.Comparator;

public class SongComparator implements Comparator<Song>{

	
	@Override
	public int compare(Song song1, Song song2) {
		//need to check if the songs are equal, if not, then return comparison of their artists
		//otherwise we return the original comparisons
		int first=song1.getTitle().toLowerCase().compareTo(song2.getTitle().toLowerCase());
		
		if (first==0) {
			return song1.getArtist().toLowerCase().compareTo(song2.getArtist().toLowerCase());
		} else {
			return first;
		}
		
		
	}
}
